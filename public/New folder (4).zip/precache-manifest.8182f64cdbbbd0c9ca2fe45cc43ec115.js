self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b7b818f82be63c64f5c8",
    "url": "/css/app.260d3b29.css"
  },
  {
    "revision": "fc194d99ea651ce25cf8",
    "url": "/css/chunk-vendors.a2036a16.css"
  },
  {
    "revision": "1594d4d0d71e55bfcb3c96f4020e5f35",
    "url": "/css/materialdesignicons.css"
  },
  {
    "revision": "595619392b0fd11530a1b2cb16d422e4",
    "url": "/fonts/materialdesignicons-webfont.eot"
  },
  {
    "revision": "61ea6a0b5aa57e34522970f3bc8f9b65",
    "url": "/fonts/materialdesignicons-webfont.ttf"
  },
  {
    "revision": "e5290ab93195775139a02839e20696b5",
    "url": "/fonts/materialdesignicons-webfont.woff"
  },
  {
    "revision": "32a98ad95363c90dbd0ebd4cef88e2d7",
    "url": "/fonts/materialdesignicons-webfont.woff2"
  },
  {
    "revision": "595619392b0fd11530a1b2cb16d422e4",
    "url": "/fonts/materialdesignicons-webfont2.eot"
  },
  {
    "revision": "5038c7d6c499c40fc27f88537277150a",
    "url": "/img/Untitled.png"
  },
  {
    "revision": "23871037b63b627a4de7da6b466e9b1a",
    "url": "/img/bg-2.jpg"
  },
  {
    "revision": "1d041efded36d700a57f8c630bdb3dc6",
    "url": "/img/report-bg.png"
  },
  {
    "revision": "c2c4c90ecc933d2add6fe542db68b69c",
    "url": "/img/vbanner.jpg"
  },
  {
    "revision": "e84ffee8ea872939ca131d7702cbacc4",
    "url": "/index.html"
  },
  {
    "revision": "b7b818f82be63c64f5c8",
    "url": "/js/app.86cba688.js"
  },
  {
    "revision": "fc194d99ea651ce25cf8",
    "url": "/js/chunk-vendors.cb730390.js"
  },
  {
    "revision": "31725d852cf4374cd1892625aa777dca",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "7530516313d2890ad10cfbe621a3ff92",
    "url": "/scripts/jwt.js"
  },
  {
    "revision": "aaf6ce8fd9c276c99714fd0d5c69d3fd",
    "url": "/scripts/rxjs.umd.min"
  },
  {
    "revision": "99a5c5cfc9efe699538a306fcc937412",
    "url": "/styles.css"
  }
]);